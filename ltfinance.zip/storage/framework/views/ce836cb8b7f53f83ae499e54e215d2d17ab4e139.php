<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['status', 'warning']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['status', 'warning']); ?>
<?php foreach (array_filter((['status', 'warning']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php
    $classes = ($warning ?? false)
                ? 'my-4 max-w-7xl m-5 bg-red-100 border-red-400 text-red-700 px-4 py-3 rounded relative'
                : 'my-4 max-w-7xl m-5 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative';
?>

<?php if($status): ?>
    <div x-data="{ open : true }">
        <div  x-show="open" <?php echo e($attributes->merge(["class" => $classes])); ?> role="alert">
    
            <span class="block sm:inline"><?php echo e($status); ?></span>
            <span class="absolute top-0 bottom-0 right-0 px-4 py-3" @click="open = ! open">
                 <svg class="fill-current h-6 w-6 text-red-500" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><title>Close</title><path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"/></svg>
            </span>
        </div>
    </div>

<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\LTFINANCE\resources\views\components\flashmessage.blade.php ENDPATH**/ ?>