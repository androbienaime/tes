<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'LTFINANCE')); ?></title>

        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        <script src="https://code.jquery.com/jquery-3.6.1.min.js" defer></script>


        <?php echo \Livewire\Livewire::styles(); ?>

        <style>
          [x-cloak] { display: none !important; }
      </style>
    </head>
    <body class="font-[Poppins] antialiased bg-gray-100">
          <div class="relative min-h-screen md:flex  " x-data="{ opens: true }">
              <!-- Sidebar -->
            <?php echo $__env->make("partials.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Main content -->
            <main class="flex-1 sm:ml-64 mb-5">
              <div class="">
                <?php echo $__env->make('partials.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <!-- Page Heading -->
                <?php if(isset($header)): ?>
                  <header class="bg-white shadow">
                      <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                          <?php echo e($header); ?>

                      </div>
                  </header>
                <?php endif; ?>
              </div>

              <div class="">
                  <?php echo e($slot); ?>

              </div>
            </main>
          </div>
          <?php echo \Livewire\Livewire::scripts(); ?>

          <script src="http://127.0.0.1:8000/vendor/livewire-charts/app.js"></script>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\LTFINANCE\resources\views/layouts/admin.blade.php ENDPATH**/ ?>