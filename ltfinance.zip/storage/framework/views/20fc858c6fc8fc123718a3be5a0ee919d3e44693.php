<div
    style="width: 100%; height: 100%;"
    x-data="{ ...livewireChartsPieChart() }"
    x-init="init()"
>
    <div wire:ignore x-ref="container"></div>
</div>

<?php /**PATH C:\xampp\htdocs\LTFINANCE\vendor\asantibanez\livewire-charts\src/../resources/views/livewire-pie-chart.blade.php ENDPATH**/ ?>