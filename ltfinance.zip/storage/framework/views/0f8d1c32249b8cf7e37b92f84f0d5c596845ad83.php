<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['names']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['names']); ?>
<?php foreach (array_filter((['names']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div>
    <?php
        $classes = "block w-full z-20 text-sm text-gray-900
                    bg-gray-50 rounded-r-lg border-l-gray-50
                    border-l-2 border border-gray-300
                    focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700
                    dark:border-l-gray-700  dark:border-gray-600
                    dark:placeholder-gray-400 dark:text-
                    white dark:focus:border-blue-500";
        $classes1 = "flex-shrink-0 z-10 inline-flex items-center
                    py-3  text-sm font-medium text-center
                    text-gray-900 bg-gray-100 border
                    border-gray-300 rounded-l-lg hover:bg-gray-200 focus:ring-4
                    focus:outline-none focus:ring-gray-100 dark:bg-gray-700
                    dark:hover:bg-gray-600 dark:focus:ring-gray-700
                    dark:text-white dark:border-gray-600 ";
    ?>
    <script>
        function intCodesComponentID() {
            return {
                intCodesID: [
                    {
                        name: "NINU",
                        dial_code: "NINU",
                        code: "NINU",
                        format: '9999999999'
                    },
                    {
                        name: "NIF",
                        dial_code: "NIF",
                        code: "NIF",
                        format: '999-999-999-9'
                    }
                ],
                selectedDialCodeID: 'NINU',
                selectedFormatID: '9999999999',
                onSelectChangeHandler(e) {
                    const country = intCodesID.find((element) => {
                        return element.dial_code == this.selectedDialCodeID
                    })

                    this.selectedFormatID = country.format
                },
            }
        }
    </script>
    <div x-data="intCodesComponentID" x-init="intCodesID = window.intCodesID"
         class="appearance-none block flex w-full
     text-gray-700

    focus:outline-none focus:bg-white">
        <select id="countries" class="<?php echo e($classes1); ?>" x-model="selectedDialCodeID" @change="onSelectChangeHandler">
            <template x-for="{dial_code} in intCodesID">
                <option :value="dial_code" x-text="dial_code" :selected="dial_code == 'NINU'"></option>
            </template>
        </select>
        <input x-mask:dynamic="selectedFormatID" type="text" <?php echo $attributes->merge(['class' => $classes ]); ?> name="<?php echo e($names); ?>" autocomplete="off" :placeholder="selectedFormatID">
    </div>
</div>

<script>
    window.intCodesID = [
        {
            name: "NINU",
            dial_code: "NINU",
            code: "NINU",
            format: '9999999999'
        },
        {
            name: "NIF",
            dial_code: "NIF",
            code: "NIF",
            format: '999-999-999-9'
        }
    ];
</script>
<?php /**PATH C:\xampp\htdocs\LTFINANCE\resources\views/components/admin-id-mask.blade.php ENDPATH**/ ?>