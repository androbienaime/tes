<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(["icon_class", "title", "qty"]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(["icon_class", "title", "qty"]); ?>
<?php foreach (array_filter((["icon_class", "title", "qty"]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="p-5 bg-white rounded shadow-sm">
    <div class="flex items-center space-x-4">
        <div>
            <div class="flex items-center justify-center w-12 h-12 rounded-full bg-blue-600 text-white">
                <i width="32" class="<?php echo e($icon_class); ?>"></i>
            </div>
        </div>
        <div>
            <div class="text-gray-400"><?php echo e($title); ?></div>
            <div class="text-2xl font-bold text-gray-900"> <?php echo e($qty); ?></div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\LTFINANCE\resources\views/components/admin-card.blade.php ENDPATH**/ ?>