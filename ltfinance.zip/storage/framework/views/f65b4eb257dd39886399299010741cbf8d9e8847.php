<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['active']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['active']); ?>
<?php foreach (array_filter((['active']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    $classes = ($active ?? false)
                ? 'block cursor-pointer p-2 bg-gray-700 rounded-md mt-1 transition duration-150 ease-in-out'
                : 'block cursor-pointer p-2 hover:bg-gray-700 rounded-md mt-1 transition duration-150 ease-in-out';
    $open = ($active ?? false)
            ? "open = true"
            : ' ';


?>
<a <?php echo e($attributes->merge(['class' => $classes, 'x-bind' => $open ])); ?> >
    <?php echo e($slot); ?>

</a>
<?php /**PATH C:\xampp\htdocs\LTFINANCE\resources\views/components/admin-nav-sub-link.blade.php ENDPATH**/ ?>