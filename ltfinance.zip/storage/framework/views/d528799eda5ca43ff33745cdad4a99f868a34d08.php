<span class="block text-sm text-gray-600 sm:text-center dark:text-gray-400">LesTruviens B.G™. Tous droits réservés.</span>


<?php /**PATH C:\xampp\htdocs\LTFINANCE\resources\views\adminTheme\partials\footer.blade.php ENDPATH**/ ?>