<div class="bg-white border-t-2 text-sm font-medium text-center text-gray-500 border-b border-gray-200 dark:text-gray-400 dark:border-gray-700">
    <ul class="flex flex-wrap -mb-px">
        <?php echo e($slot); ?>

    </ul>
</div>
<?php /**PATH C:\xampp\htdocs\LTFINANCE\resources\views\components\admin-tab.blade.php ENDPATH**/ ?>