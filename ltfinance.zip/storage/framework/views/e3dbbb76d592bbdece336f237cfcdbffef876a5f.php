<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['iconLeft', 'titles']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['iconLeft', 'titles']); ?>
<?php foreach (array_filter((['iconLeft', 'titles']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div x-data="{open : false, toggle() { open: true } }">
    <!-- Menu DropDown -->
    <div @click="open = !open" class="p-2.5 mt-3 flex items-center rounded-md px-4 duration-300
                        cursor-pointer hover:bg-blue-600 text-white" >
        <i <?php echo e($attributes->merge(['class' => $iconLeft])); ?> ></i>
        <div class="flex justify-between w-full items-center">
            <span class="text-[15px] ml-4 text-gray-200"><?php echo e(__($titles)); ?></span>
            <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path x-show="! open" d="M9 5L16 12L9 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: none;"></path>
                <path x-show="open" d="M19 9L12 16L5 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
            </svg>
        </div>
    </div>

    <!-- SubMenu -->
    <div x-show="open" class="text-left text-sm font-thin mt-2 w-4/5 mx-auto text-gray-200" id="dropdown-example">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\LTFINANCE\resources\views\components\admin-sidebar-menu-dropdown.blade.php ENDPATH**/ ?>