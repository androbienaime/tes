<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['title', 'cs']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['title', 'cs']); ?>
<?php foreach (array_filter((['title', 'cs']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<!-- Panel -->
<div class="max-w-7xl mb-2 border-solid border-grey-light rounded border shadow-sm m-5 ">
    <div class="bg-white px-2 py-3 text-gray-700 border border-gray-200 bg-gray-50 dark:bg-gray-800 dark:border-gray-700 ">
      <?php if($title): ?>
            <span class='text-md'><i class='<?php echo e($cs); ?>'></i> <?php echo e($title); ?></span>
        <?php endif; ?>
    </div>
    <div class="p-3 bg-white">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\LTFINANCE\resources\views/components/primary-panel.blade.php ENDPATH**/ ?>