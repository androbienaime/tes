<div
    style="width: 100%; height: 100%;"
    x-data="{ ...livewireChartsMultiColumnChart() }"
    x-init="init()"
>
    <div wire:ignore x-ref="container"></div>
</div>

<?php /**PATH C:\xampp\htdocs\LTFINANCE\vendor\asantibanez\livewire-charts\resources\views\livewire-multi-column-chart.blade.php ENDPATH**/ ?>