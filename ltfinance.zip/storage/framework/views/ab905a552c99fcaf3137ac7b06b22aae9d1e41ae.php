<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <?php
        if(Illuminate\Support\Facades\Gate::denies("isAdmin")){
            $rep = new \App\Http\Controllers\Admin\ReportController();
            $data = $rep->showDashEmployeeHistory(\App\Models\Employee::find(Auth::user()->id));

            $customer_count = $data["customer_count"];
            $sumDepositByDay = $data["sumDepositByDay"];
            $sumDepositByMonth = $data["sumDepositByMonth"];
            $sumWithdrawByDay = $data["sumWithdrawByDay"];
        }

    ?>

    <div class="py-5">
        <div class="max-w-7xl mx-auto sm:px-4 lg:px-4">
            <div class="overflow-hidden shadow-sm sm:rounded-lg">
                <div class="">
                        <?php echo $__env->make("adminTheme.partials.cards", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("access-settings")): ?>
                        <div class="grid gap-6 mb-6 md:grid-cols-2 p-4" >
                            <div class="bg-white shadow-md rounded p-2">
                                <div style="height: 24rem">
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('livewire-column-chart', ['columnChartModel' => $columnChartModel])->html();
} elseif ($_instance->childHasBeenRendered(''.e($columnChartModel->reactiveKey()).'')) {
    $componentId = $_instance->getRenderedChildComponentId(''.e($columnChartModel->reactiveKey()).'');
    $componentTag = $_instance->getRenderedChildComponentTagName(''.e($columnChartModel->reactiveKey()).'');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(''.e($columnChartModel->reactiveKey()).'');
} else {
    $response = \Livewire\Livewire::mount('livewire-column-chart', ['columnChartModel' => $columnChartModel]);
    $html = $response->html();
    $_instance->logRenderedChild(''.e($columnChartModel->reactiveKey()).'', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                </div>
                            </div>
                            <div class="bg-white shadow-md rounded p-2 w-full">
                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('livewire-pie-chart', ['pieChartModel' => $pieChartModel])->html();
} elseif ($_instance->childHasBeenRendered(''.e($pieChartModel->reactiveKey()).'')) {
    $componentId = $_instance->getRenderedChildComponentId(''.e($pieChartModel->reactiveKey()).'');
    $componentTag = $_instance->getRenderedChildComponentTagName(''.e($pieChartModel->reactiveKey()).'');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(''.e($pieChartModel->reactiveKey()).'');
} else {
    $response = \Livewire\Livewire::mount('livewire-pie-chart', ['pieChartModel' => $pieChartModel]);
    $html = $response->html();
    $_instance->logRenderedChild(''.e($pieChartModel->reactiveKey()).'', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\LTFINANCE\resources\views\adminTheme\dashboard.blade.php ENDPATH**/ ?>