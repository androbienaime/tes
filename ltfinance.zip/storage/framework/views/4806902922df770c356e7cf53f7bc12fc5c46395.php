<?php
    $theme = $component->getTheme();
?>

<?php if($theme === 'tailwind'): ?>
    <div class="rounded-md">
        <div>
            <input
                type="checkbox"
                id="<?php echo e($component->getTableName()); ?>-filter-<?php echo e($filter->getKey()); ?>-select-all"
                wire:input="selectAllFilterOptions('<?php echo e($filter->getKey()); ?>')"
                <?php echo e(count($component->getAppliedFilterWithValue($filter->getKey()) ?? []) === count($filter->getOptions()) ? 'checked' : ''); ?>


                class="text-indigo-600 rounded border-gray-300 shadow-sm transition duration-150 ease-in-out focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 dark:bg-gray-900 dark:text-white dark:border-gray-600 dark:hover:bg-gray-600 dark:focus:bg-gray-600 disabled:opacity-50 disabled:cursor-wait"
            >
            <label for="<?php echo e($component->getTableName()); ?>-filter-<?php echo e($filter->getKey()); ?>-select-all" class="dark:text-white"><?php echo app('translator')->get('All'); ?></label>
        </div>

        <?php $__currentLoopData = $filter->getOptions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div wire:key="<?php echo e($component->getTableName()); ?>-filter-<?php echo e($filter->getKey()); ?>-multiselect-<?php echo e($key); ?>">
                <input
                    type="checkbox"
                    id="<?php echo e($component->getTableName()); ?>-filter-<?php echo e($filter->getKey()); ?>-<?php echo e($loop->index); ?>"
                    value="<?php echo e($key); ?>"
                    wire:key="<?php echo e($component->getTableName()); ?>-filter-<?php echo e($filter->getKey()); ?>-<?php echo e($loop->index); ?>"
                    wire:model.stop="<?php echo e($component->getTableName()); ?>.filters.<?php echo e($filter->getKey()); ?>"
                    <?php echo e(count($component->getAppliedFilterWithValue($filter->getKey()) ?? []) === count($filter->getOptions()) ? 'disabled' : ''); ?>

                    :class="{'disabled:bg-gray-400 disabled:hover:bg-gray-400' : <?php echo e(count($component->getAppliedFilterWithValue($filter->getKey()) ?? []) === count($filter->getOptions()) ? 'true' : 'false'); ?>}"
                    class="text-indigo-600 rounded border-gray-300 shadow-sm transition duration-150 ease-in-out focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 dark:bg-gray-900 dark:text-white dark:border-gray-600 dark:hover:bg-gray-600 dark:focus:bg-gray-600 disabled:opacity-50 disabled:cursor-wait"
                >
                <label for="<?php echo e($component->getTableName()); ?>-filter-<?php echo e($filter->getKey()); ?>-<?php echo e($loop->index); ?>" class="dark:text-white"><?php echo e($value); ?></label>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php elseif($theme === 'bootstrap-4' || $theme === 'bootstrap-5'): ?>
    <div class="form-check">
        <input
            type="checkbox"
            id="<?php echo e($component->getTableName()); ?>-filter-<?php echo e($filter->getKey()); ?>-select-all"
            wire:input="selectAllFilterOptions('<?php echo e($filter->getKey()); ?>')"
            <?php echo e(count($component->getAppliedFilterWithValue($filter->getKey()) ?? []) === count($filter->getOptions()) ? 'checked' : ''); ?>

            class="form-check-input"
        >
        <label class="form-check-label" for="<?php echo e($component->getTableName()); ?>-filter-<?php echo e($filter->getKey()); ?>-select-all"><?php echo app('translator')->get('All'); ?></label>
    </div>

    <?php $__currentLoopData = $filter->getOptions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-check" wire:key="<?php echo e($component->getTableName()); ?>-filter-<?php echo e($filter->getKey()); ?>-multiselect-<?php echo e($key); ?>">
            <input
                class="form-check-input"
                type="checkbox"
                id="<?php echo e($component->getTableName()); ?>-filter-<?php echo e($filter->getKey()); ?>-<?php echo e($loop->index); ?>"
                value="<?php echo e($key); ?>"
                wire:key="<?php echo e($component->getTableName()); ?>-filter-<?php echo e($filter->getKey()); ?>-<?php echo e($loop->index); ?>"
                wire:model.stop="<?php echo e($component->getTableName()); ?>.filters.<?php echo e($filter->getKey()); ?>"
            >
            <label class="form-check-label" for="<?php echo e($component->getTableName()); ?>-filter-<?php echo e($filter->getKey()); ?>-<?php echo e($loop->index); ?>"><?php echo e($value); ?></label>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\LTFINANCE\vendor\rappasoft\laravel-livewire-tables\resources\views\components\tools\filters\multi-select.blade.php ENDPATH**/ ?>