<x-guest-layout>
    @include("auth.passwords.partials.update-password-form")
</x-guest-layout>
