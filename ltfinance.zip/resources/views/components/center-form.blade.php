<div class="flex flex-col items-center">
    <div class="w-full md:w-1/2 flex flex-col items-center ">
        <div class="w-full px-4">
            <div class="flex flex-col items-center relative">
                <div class="w-full">
                    {{ $slot }}
                </div>
            </div>
        </div>
    </div>
</div>
