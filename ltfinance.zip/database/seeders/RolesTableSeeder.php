<?php

namespace Database\Seeders;

use App\Models\Role;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class RolesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Role::create([
           "name" => "SuperAdmin"
        ]);

        Role::create([
            "name" => "Director"
        ]);

        Role::create([
            "name" => "Cashier"
        ]);

    }
}
