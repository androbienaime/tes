<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Address extends Model
{
    protected $fillable = ["city", "country", "state", "email", "phone", "address1"];
    use HasFactory;

    public function Branch(){
        return $this->hasOne(Branch::class);
    }

    public function Account(){
        return $this->hasOne(Account::class);
    }

    public function Employee(){
        return $this->hasOne(Account::class);
    }
}
